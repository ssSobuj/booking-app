import { Link } from "react-router-dom";
import "./profile.css";
import { FaFacebookF } from "react-icons/fa";
import { FaTwitter } from "react-icons/fa";
import { FaInstagram } from "react-icons/fa6";
import ModalForm from "../../component/modalForm/ModalForm";
import { useState } from "react";
import { useAuth } from "./../../context/AuthProbider";
import { CgProfile } from "react-icons/cg";

export default function Profile() {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const { authState } = useAuth();
  const {
    currentUser: { city, country, email, phone, username },
  } = authState;

  const filterName = username
    .split("")
    .filter((item) => isNaN(item))
    .join("");
  const name = filterName.charAt(0).toUpperCase() + filterName.slice(1);

  const openModal = () => {
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };
  return (
    <>
      <div className="profile-page-content">
        <div className="profile-card">
          <div className="profile-user-profile">
            <div className="profile-card-img">
              <div className="profile-user-icon">
                <CgProfile className="icon" />
                {/* <img
                  src="https://svgsilh.com/svg/659651.svg"
                  alt="User-Profile-Image"
                /> */}
              </div>
              <div className="content">
                <h6>Hembo Tingor</h6>
                <p>Web Designer</p>
              </div>
            </div>
          </div>
          <div className="profile-card-block">
            <h5 className="custom-section-title">Information</h5>
            <hr />
            <div className="custom-user-info-row">
              <div className="custom-user-info">
                <p className="custom-info-label">Name</p>
                <h6>{name}</h6>
              </div>
              <div className="custom-user-info">
                <p className="custom-info-label">UserName</p>
                <h6>{username.slice(0, 15)}</h6>
              </div>
            </div>
            <div className="custom-user-info-row">
              <div className="custom-user-info">
                <p className="custom-info-label">Email</p>
                <h6>{email}</h6>
              </div>
              <div className="custom-user-info">
                <p className="custom-info-label">Phone</p>
                <h6>{phone}</h6>
              </div>
            </div>
            <div className="custom-user-info-row">
              <div className="custom-user-info">
                <p className="custom-info-label">Country</p>
                <h6>{country}</h6>
              </div>
              <div className="custom-user-info">
                <p className="custom-info-label">City</p>
                <h6>{city}</h6>
              </div>
            </div>
            <div className="edit-btn">
              <button onClick={openModal}>
                <strong>Edit Profile</strong>
              </button>
            </div>
            <ul className="custom-social-links">
              <li>
                <Link>
                  <FaFacebookF className="custom-social-link" />
                </Link>
              </li>
              <li>
                <Link>
                  <FaTwitter className="custom-social-link" />
                </Link>
              </li>
              <li>
                <Link>
                  <FaInstagram className="custom-social-link" />
                </Link>
              </li>
            </ul>
          </div>
        </div>
        {isModalOpen && (
          <div className="modal-wrap">
            <ModalForm showModal={isModalOpen} closeModal={closeModal} />
          </div>
        )}
      </div>
    </>
  );
}
